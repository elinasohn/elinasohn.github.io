// Scale Animation Setup
// .to('@target', @length, {@object})
var scale_tween = TweenMax.to('#scale-animation', 1, {
    transform: 'scale(.75)',
    ease: Linear.easeNone
  });
  
  // BG Animation Setup
  // .to('@target', @length, {@object})
  var bg_tween = TweenMax.to('#bg-trigger', 1, {
    backgroundColor: '#FFA500',
    ease: Linear.easeNone
  });

  // init ScrollMagic Controller
  var controller = new ScrollMagic.Controller();
  
  
  // Scale Scene
  var scale_scene = new ScrollMagic.Scene({
    triggerElement: '#scale-trigger'
  })
  .setTween(scale_tween);
  
  // Background Scene
  var bg_scene = new  ScrollMagic.Scene({
    triggerElement: '#bg-trigger'
  })
  .setTween(bg_tween);
